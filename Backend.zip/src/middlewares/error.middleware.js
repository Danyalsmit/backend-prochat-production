const errorHandler = (
  err,
  req,
  res,
  next
) => {

  const statusCode =
    err.statusCode || 500;

  return res.status(statusCode).json({
    success: false,
    message:
      err.message ||
      "Internal Server Error"
  });
};

module.exports = errorHandler;